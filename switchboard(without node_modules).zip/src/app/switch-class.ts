export class SwitchClass {
}
